<script src="public/js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
<textarea name="detail_desc" id="detail_desc" class="ckeditor"></textarea>